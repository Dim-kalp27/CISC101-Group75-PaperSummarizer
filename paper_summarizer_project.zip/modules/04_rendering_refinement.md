# Module 4 — Rendering & Refinement

- Format outputs into required structure:
  - Paper Summary
  - Section-by-Section Summary Table
  - Expert Summary
  - Lay Summary
  - Mini-Glossary
  - Checks & Warnings

- Ensure consistent terminology and academic tone.
