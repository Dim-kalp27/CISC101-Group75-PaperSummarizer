# Module 6 — Equation & Technical Term Explainer

- Detect equations and technical terms in the text.
- Provide simple, non-expert explanations.
- Ensure accuracy while avoiding oversimplification.
