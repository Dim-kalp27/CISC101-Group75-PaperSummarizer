# Module 3 — Guardrails

- Prevent hallucinations: summarize only provided text.
- Enforce strict evidence rules.
- Handle missing or short sections with warnings.
- Apply chunking for long text to avoid omissions.
