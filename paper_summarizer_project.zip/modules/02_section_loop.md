# Module 2 — Section Loop

For each section:
- Summarize within 100–150 words.
- Apply word-limit tests and flag violations.
- Generate two variants:
  - Expert summary (technical, precise).
  - Lay summary (simplified, accessible).
