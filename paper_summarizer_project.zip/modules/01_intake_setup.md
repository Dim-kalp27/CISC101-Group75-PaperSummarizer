# Module 1 — Intake & Setup
- Normalize section names (e.g., "Intro" → "Introduction").
- Detect missing or short (<50 words) sections.
- Apply chunking strategies for long papers.
- Prepare metadata for each section (title, boundaries, length).
